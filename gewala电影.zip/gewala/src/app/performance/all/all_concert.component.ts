/**
 * Created by zzq on 2018/1/16.
 */
import {Component,OnInit}from'@angular/core';

@Component({
  selector:'app-all_concert',
  templateUrl:'all_concert.component.html',
  styleUrls:['all_concert.component.css']
})

export class AllConcertComponent implements OnInit{
  constructor(){}
  ngOnInit(){}
}
