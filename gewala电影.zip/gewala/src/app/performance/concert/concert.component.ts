/**
 * Created by zzq on 2018/1/16.
 */
/**
 * Created by zzq on 2018/1/16.
 */
import {Component,OnInit}from'@angular/core';

@Component({
  selector:'app-concert',
  templateUrl:'concert.component.html',
  styleUrls:['concert.component.css']
})

export class ConcertComponent implements OnInit{
  constructor(){}
  ngOnInit(){}
}
