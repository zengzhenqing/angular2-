/**
 * Created by zzq on 2018/1/15.
 */
import {Component,OnInit}from'@angular/core'

@Component({
  selector:'app-performance',
  templateUrl:'performance.component.html',
  styleUrls:['performance.component.css']
})

export class PerformanceComponent implements OnInit{
  constructor(){}
  ngOnInit(){}
}
