/**
 * Created by zzq on 2018/1/16.
 */
import {Component,OnInit}from'@angular/core';

@Component({
  selector:'app-vocal',
  templateUrl:'vocal.component.html',
  styleUrls:['vocal.component.css']
})

export class VocalComponent implements OnInit{
  constructor(){}
  ngOnInit(){}
}
