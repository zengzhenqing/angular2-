/**
 * Created by zzq on 2018/1/17.
 */
export class Cinema{
  id:number;
  name:string;
  address:string;
  score:number;
  session:string;
}
