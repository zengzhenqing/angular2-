/**
 * Created by zzq on 2018/1/15.
 */
import {Component,OnInit}from'@angular/core';
import {CinemaService}from'./cinema.service';
import {Cinema} from "./cinema_detail";


@Component({
  selector:'app-cinema',
  templateUrl:'cinema.component.html',
  styleUrls:['cinema.component.css'],
  providers: [CinemaService]
})

export class CinemaComponent implements OnInit{

  cinemas: Cinema[];
  selectedcinema: Cinema;

  constructor(private cinemaService: CinemaService){}
  getCinemas(): void {
    this.cinemaService.getCinemas().then(cinemas => this.cinemas = cinemas );
  }


  ngOnInit():void{
    this.getCinemas();
  }
  onSelect(cinema: Cinema): void {
    this.selectedcinema = cinema;
  }

}
