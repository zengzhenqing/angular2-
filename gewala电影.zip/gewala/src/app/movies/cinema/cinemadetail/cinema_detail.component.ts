/**
 * Created by zzq on 2018/1/17.
 */
import 'rxjs/add/operator/switchMap';
import { Component, OnInit }        from '@angular/core';
import { ActivatedRoute, ParamMap } from '@angular/router';
import { Location }                 from '@angular/common';
import {Cinema}from'../cinema_detail';
import {CinemaService}from'../cinema.service'

@Component({
  selector:'cinema-detail',
  templateUrl:'cinema_detail.html',
  styleUrls:['cinema_detail.css']
})
export class CinemaDetailComponent implements OnInit{
  cinema: Cinema;

  constructor(
    private cinemaService: CinemaService,
    private route: ActivatedRoute,
    private location: Location
  ){}

  ngOnInit():void{
    this.route.paramMap
      .switchMap((params: ParamMap) => this.cinemaService.getCinema(+params.get('id')))
      .subscribe(cinema => this.cinema = cinema);
  }
  goBack(): void {
    this.location.back();
  }
}
