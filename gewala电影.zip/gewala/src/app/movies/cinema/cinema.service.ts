/**
 * Created by zzq on 2018/1/17.
 */
import {Injectable}from'@angular/core';

import {Cinema}from'./cinema_detail'
import {CINEMAS}from'./cinema_list';

@Injectable()

export class CinemaService{
  getCinemas(): Promise<Cinema[]> {
    return Promise.resolve(CINEMAS);
  }
  getCinema(id: number): Promise<Cinema> {
    return this.getCinemas()
      .then(cinemas => cinemas.find(cinema => cinema.id === id));
  }

}

