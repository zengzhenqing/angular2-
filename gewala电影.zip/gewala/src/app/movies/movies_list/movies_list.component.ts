/**
 * Created by zzq on 2018/1/15.
 */
import {Component,OnInit} from '@angular/core'
import {HttpClient} from "@angular/common/http";

@Component({
  selector:'app-movieslist',
  templateUrl:'movies_list.component.html',
  styleUrls:['movies_list.component.css']
})

export class MovieslistComponent implements OnInit{
  total;
  movies;
  constructor(private http: HttpClient){}
  ngOnInit(){
    this.http.get('/assets/hot_movie.json').subscribe(data=> {
      console.log(data);
      this.total = data['total'];
      this.movies = data['subjects'];
    })
  }
}
