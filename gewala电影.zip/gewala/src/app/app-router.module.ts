/**
 * Created by zzq on 2018/1/15.
 */
import {NgModule}from '@angular/core';
import {RouterModule,Routes}from'@angular/router';


import {MoviesComponent}from'./movies/movies.component';
import {PerformanceComponent}from'./performance/performance.component';
import {LoginComponent}from'./login/login.component';
import {SigninComponent}from'./signin/signin.component';
import {MainpageComponent}from'./mainpage/mainpage.component';
import {MovieslistComponent}from'./movies/movies_list/movies_list.component';
import {CinemaComponent}from'./movies/cinema/cinema.component'
import {ConcertComponent}from'./performance/concert/concert.component';
import {VocalComponent}from'./performance/vocal/vocal.component';
import {AllConcertComponent}from'./performance/all/all_concert.component'
import {CinemaDetailComponent}from'./movies/cinema/cinemadetail/cinema_detail.component';
import {CinemaService}from'./movies/cinema/cinema.service'

const appChildRout:Routes = [
  {
    path: '' ,
    redirectTo:'allconcert',
    pathMatch:'full'
  },
  {
    path:'allconcert',
    component:AllConcertComponent
  },
  {
    path:'concert',
    component:ConcertComponent
  },
  {
    path:'vocal',
    component:VocalComponent
  }
]
const appChildRoutes: Routes = [
  {
    path: '' ,
    redirectTo:'movieslist',
    pathMatch:'full'
  },
  {
    path:'movieslist',
    component:MovieslistComponent
  },
  {
    path:'cinema',
    component:CinemaComponent
  },
];

const routes:Routes = [
  {
    path: '' ,
    redirectTo:'main',
    pathMatch:'full'
  },
  {
    path:'main',
    component:MainpageComponent
  },
  {
    path:'movies',
    component:MoviesComponent,
    children:appChildRoutes
  },
  {
    path:'performance',
    component:PerformanceComponent,
    children:appChildRout
  },
  {
    path:'login',
    component:LoginComponent
  },
  {
    path:'signin',
    component:SigninComponent
  },
  {
    path: 'detail/:id',
    component: CinemaDetailComponent
  },
  // ,
  // {
  //   path:'movieslist',
  //   component:MovieslistComponent
  // },
  // {
  //   path:'cinema',
  //   component:CinemaComponent
  // }
]


@NgModule({
  imports:[RouterModule.forRoot(routes)],
  exports:[RouterModule]
})
export class AppRoutingModule{

}
