import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { HttpClientModule }from'@angular/common/http'


import {AppRoutingModule}from'./app-router.module';
import { AppComponent } from './app.component';
import {MoviesComponent}from'./movies/movies.component';
import {PerformanceComponent}from'./performance/performance.component';
import {LoginComponent}from'./login/login.component';
import {SigninComponent}from'./signin/signin.component';
import {MainpageComponent}from'./mainpage/mainpage.component'
import {MovieslistComponent}from'./movies/movies_list/movies_list.component';
import {CinemaComponent}from'./movies/cinema/cinema.component'
import {ConcertComponent}from'./performance/concert/concert.component';
import {VocalComponent}from'./performance/vocal/vocal.component';
import {AllConcertComponent}from'./performance/all/all_concert.component'
import {CinemaDetailComponent}from'./movies/cinema/cinemadetail/cinema_detail.component';
import {CinemaService}from'./movies/cinema/cinema.service'


@NgModule({
  declarations: [
    AppComponent,
    MoviesComponent,
    PerformanceComponent,
    LoginComponent,
    SigninComponent,
    MainpageComponent,
    MovieslistComponent,
    CinemaComponent,
    AllConcertComponent,
    ConcertComponent,
    VocalComponent,
    CinemaDetailComponent,

  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpModule,
    HttpClientModule
  ],
  providers: [CinemaService],
  bootstrap: [AppComponent]
})
export class AppModule { }
